var drive;



$(function Controller(){
    drive = require(header.url + "resources/xml/" +  header.archivo);    
})