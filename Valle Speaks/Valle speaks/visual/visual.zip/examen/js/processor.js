

/**
 * Shuffles array in place.
 * @param {Array} a items An array containing the items.
 */
function shuffle(a) {
    var j, x, i;
    for (i = a.length - 1; i > 0; i--) {
        j = Math.floor(Math.random() * (i + 1));
        x = a[i];
        a[i] = a[j];
        a[j] = x;
    }
    return a;
}

function copyr(a){
	var reply = new Array()
	for(j = 0; j < a.length; j++)
		reply.push(a[j]);
	return reply;
}

function OnEndTimeTest(){
	$('#time').html('Fin del examen');
	console.log('Fin del examen');
}

function Start(){
	ControllerTime(function(){
		OnEndTimeTest();
	});
}

$("#btnStart").on( "click", function() {
	Start()
	// 'rounded' is the class I'm applying to the toast
	M.toast({html: 'Mucha suerte, ¡Tu eres el mejor!', classes: 'rounded'});

	$("#btnStart").hide();

	$('.fixed-action-btn').show();

	$('#preguntas').html('');

	//$('#finish-btnExam-help').tapTarget('open')
});

$(function Controller(){	
	
})