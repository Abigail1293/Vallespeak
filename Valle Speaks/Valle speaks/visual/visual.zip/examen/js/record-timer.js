var days = 0;
var hours = 0;
var seconds = 0;
var x;

const HOUR_FOR_EXAM = 2;
const MINUTES_FOR_EXAM = 0;

// Set the date we're counting down to
var nowDate = new Date();
nowDate.setHours(nowDate.getHours() + HOUR_FOR_EXAM);
nowDate.setMinutes(nowDate.getMinutes() + MINUTES_FOR_EXAM);
const countDownDate = nowDate.getTime();

function setTime(cb) {
  // Get today's date and time
  var now = new Date().getTime();

  // Find the distance between now and the count down date
  var distance = countDownDate - now;

  // Time calculations for days, hours, minutes and seconds
  days = Math.floor(distance / (1000 * 60 * 60 * 24));
  hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  seconds = Math.floor((distance % (1000 * 60)) / 1000);
  
  //document.getElementById("demo").innerHTML = days + "d " + hours + "h " + minutes + "m " + seconds + "s ";

  // If the count down is finished, write some text 
  if (distance < 0) {   
    try{      
      clearInterval(x);
      cb();      
    } 
    catch(e){
      console.log(e);
    }    
  }
  // Display the result in the element with id="demo"
  $('#time').html(getTime());
}

function getTime(){
	return hours + "h " + minutes + "m " + seconds + "s ";
}

function ControllerTime(cb){  
  x = setInterval(function(){ 
    setTime(cb); 
  } , 1000);
}

$(function Controller(){	
	//ControllerTime(null);
})