'use strict';

module.exports = require('../build/Release/canvas.node');
