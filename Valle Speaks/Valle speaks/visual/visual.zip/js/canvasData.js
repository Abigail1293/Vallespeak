function initCanvas() {
	//var canvas = document.getElementById("the-canvas");
    //if(canvas.toDataURL() != document.getElementById('blank').toDataURL())saveCanvas(canvas);
}

function saveCanvas(canvas) {
	//console.log(canvas.toDataURL());
	//addToJson(10, canvas.toDataURL());
}